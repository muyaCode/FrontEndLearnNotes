export const output = (content : string) => {
    return content
}