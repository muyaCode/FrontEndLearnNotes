console.log('print.js被加载了~');

function print() {
  const content = 'hello print'; console.log(content)();
}

export default print;
