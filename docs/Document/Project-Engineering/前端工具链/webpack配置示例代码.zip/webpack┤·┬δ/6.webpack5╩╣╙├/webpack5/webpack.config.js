module.exports = {
  mode: 'production'
};
