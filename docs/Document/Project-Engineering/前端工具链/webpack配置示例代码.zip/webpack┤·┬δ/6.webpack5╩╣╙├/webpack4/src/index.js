import * as b from './b';

console.log(b.a.name);
