export default class Skin1{
    constructor(){
        this.name = "皮肤一";
        this.ico = "./sources/heroes/yase1.png";
        this.img = "./sources/skins/301660.png";
    }
}