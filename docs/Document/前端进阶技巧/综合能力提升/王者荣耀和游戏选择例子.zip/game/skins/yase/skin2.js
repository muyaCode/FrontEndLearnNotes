export default class Skin2{
    constructor(){
        this.name = "皮肤二";
        this.ico = "./sources/heroes/yase2.png";
        this.img = "./sources/skins/301661.png";
    }
}