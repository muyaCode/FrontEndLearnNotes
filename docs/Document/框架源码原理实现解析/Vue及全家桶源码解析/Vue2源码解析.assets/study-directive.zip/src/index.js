import Vue from './Vue.js';

window.Vue = Vue;